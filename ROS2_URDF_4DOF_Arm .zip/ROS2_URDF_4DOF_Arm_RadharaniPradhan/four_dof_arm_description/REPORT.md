# URDF Modeling of a 4-DOF Industrial Robotic Arm in ROS 2

**Author:** Radharani Pradhan  **Platform:** ROS 2 Humble, Ubuntu 22.04  **Package:** `four_dof_arm_description`

> **Honesty note:** The model, launch file, RViz configuration and validator were written and the validator's logic was exercised in a non-ROS sandbox. The ROS 2 build, launch, RViz and TF tests in Section 11 have **not been run**; fill in the results column only after running them yourself.

## 1. Abstract
This project presents a URDF/Xacro description of a 4-degree-of-freedom articulated industrial robotic arm packaged as a ROS 2 (ament_python) package. The model has six links and five joints (four revolute, one fixed tool mount) built from box and cylinder primitives with physically consistent inertial properties. A launch file processes the Xacro, starts `robot_state_publisher` and `joint_state_publisher_gui`, and opens RViz2 with a preconfigured view. A Python script automatically checks structural correctness of the model.

## 2. Introduction
Robot description files are the foundation of ROS-based robotics: visualization, TF, motion planning and simulation all start from the URDF. Xacro adds macros and properties, reducing duplication and errors. This project applies these tools to a simple industrial-style arm.

## 3. Problem Statement
Create a correct, parameterised, visualizable and verifiable kinematic model of a 4-DOF arm in ROS 2, with a reproducible workflow that a beginner can build and test.

## 4. Objectives
1. Model a 4-DOF arm with the prescribed links and joints.
2. Provide visual, collision and inertial data for every link.
3. Visualize the model and its TF frames in RViz2 with interactive joint control.
4. Provide an automated validation script.
5. Document build, launch, test and troubleshooting procedures.

## 5. Robot Design
The arm is a serial chain: a fixed base, a rotating shoulder (yaw), two pitch joints (shoulder and elbow) and a wrist rotating about X, followed by a rigidly mounted tool. Dimensions: base Ø0.20×0.06 m, shoulder Ø0.12×0.10 m, upper arm 0.30 m, forearm 0.25 m, wrist 0.08 m, tool 0.06 m. Total reach at zero pose to the tool origin is 0.79 m. Masses range from 0.2 to 2.0 kg. Each segment has a distinct colour (grey, blue, orange, green, yellow, red).

## 6. URDF Implementation
File: `urdf/four_dof_arm.urdf.xacro`. Dimensions are Xacro properties. Macros `box_link`, `cyl_link`, `box_inertia` and `cyl_inertia` generate links; inertia tensors use the solid-box formula I = m(a²+b²)/12 and solid-cylinder formulas Ixx = Iyy = m(3r²+h²)/12, Izz = mr²/2, giving positive, triangle-inequality-valid values. Every link frame lies at the proximal joint with geometry and centre of mass offset by half the link length along +Z, so joint origins equal the previous link length.

## 7. Joints
| Joint | Type | Parent → Child | Axis | Origin z (m) | Limits (rad) | Effort (N·m) | Velocity (rad/s) |
|---|---|---|---|---|---|---|---|
| joint_1 | revolute | base_link → shoulder_link | Z | 0.06 | ±3.1416 | 50 | 2.0 |
| joint_2 | revolute | shoulder_link → upper_arm_link | Y | 0.10 | ±1.8 | 50 | 2.0 |
| joint_3 | revolute | upper_arm_link → forearm_link | Y | 0.30 | ±2.4 | 30 | 2.5 |
| joint_4 | revolute | forearm_link → wrist_link | X | 0.25 | ±3.1416 | 10 | 3.0 |
| tool_fixed_joint | fixed | wrist_link → tool_link | – | 0.08 | – | – | – |

## 8. Coordinate Frames
All frames follow the ROS convention (X forward, Y left, Z up). `base_link` is the root, at the centre of the base underside. Each child frame is a pure translation along the parent's Z (no fixed rotations), so at the zero configuration all frames share the same orientation and the arm is vertical. Positive rotation about an axis follows the right-hand rule.

## 9. RViz Visualization
`rviz/display.rviz` uses Fixed Frame `base_link` and three displays: Grid, RobotModel (topic `/robot_description`, transient-local durability) and TF (axes and names). `joint_state_publisher_gui` supplies slider-controlled `/joint_states`; `robot_state_publisher` converts them into TF.

## 10. TF Tree
```
base_link → shoulder_link → upper_arm_link → forearm_link → wrist_link → tool_link
```
Movable transforms are published on `/tf`; the fixed `wrist_link → tool_link` is on `/tf_static`. Expected `base_link → tool_link` at zero pose: translation [0, 0, 0.790], identity rotation.

## 11. Testing Methodology and Results
Tests are run by `validate_urdf` (≈85 checks: XML validity, required links/joints, parent-child pairs, 4 revolute + 1 fixed, axes, limits, origins, visual/collision geometry, mass/inertia, unique colours, single root/no orphans/chain order) and by ROS command-line tools.

| # | Test | Command | Status | Result (fill in) |
|---|------|---------|--------|------------------|
| 1 | Package builds | `colcon build --packages-select four_dof_arm_description` | **Not yet run** | |
| 2 | Python validator on real xacro | `ros2 run four_dof_arm_description validate_urdf` | **Not yet run** | |
| 3 | URDF parser | `check_urdf` on xacro output | **Not yet run** | |
| 4 | Launch starts 3 nodes | `ros2 launch … display.launch.py`, `ros2 node list` | **Not yet run** | |
| 5 | RViz shows model, TF, grid | visual inspection | **Not yet run** | |
| 6 | TF tree | `ros2 run tf2_tools view_frames` | **Not yet run** | |
| 7 | Zero-pose transform [0,0,0.79] | `ros2 run tf2_ros tf2_echo base_link tool_link` | **Not yet run** | |
| 8 | Slider motion changes transform | move sliders, repeat #7 | **Not yet run** | |

*Development-environment check (not a ROS test):* the validator logic was run against a URDF produced by a temporary stand-in macro expander (not the real `xacro` tool) and reported 87/87 checks passing; a deliberately wrong axis was correctly reported as FAIL. This does not replace tests 1–8.

## 12. Limitations
- Kinematic/visual model only: no `ros2_control`, controllers or simulation plugins (Gazebo).
- Primitive geometry; no meshes. Inertias are idealised solid shapes, not measured.
- Joint limits, efforts and velocities are representative, not from a real manufacturer.
- No self-collision tuning or kinematics (IK) solver.
- Not yet tested on ROS 2 Iron.

## 13. Future Enhancements
Add mesh models; `ros2_control` and Gazebo/Ignition support; MoveIt 2 configuration with an IK solver; a gripper; forward/inverse kinematics analysis against TF output; automated `launch_testing`/`pytest` integration.

## 14. Conclusion
A complete, parameterised 4-DOF arm description with launch, RViz and validation tooling was produced following ROS 2 package conventions. Its correctness on a real ROS 2 installation must be confirmed by executing Section 11 and attaching the genuine screenshots listed in `docs/SCREENSHOT_GUIDE.md`.

## Appendix – Screenshots
Insert only real screenshots captured by the author: see `docs/SCREENSHOT_GUIDE.md`.
