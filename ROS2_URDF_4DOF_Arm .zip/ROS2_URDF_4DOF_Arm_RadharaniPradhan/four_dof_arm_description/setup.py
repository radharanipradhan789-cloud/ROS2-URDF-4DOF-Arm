import os
from glob import glob
from setuptools import setup

package_name = 'four_dof_arm_description'

setup(
    name=package_name,
    version='1.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*.xacro')),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        (os.path.join('share', package_name, 'rviz'), glob('rviz/*.rviz')),
        (os.path.join('share', package_name, 'docs'), glob('docs/*.md')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Radharani Pradhan',
    maintainer_email='radharani.pradhan@example.com',
    description='URDF/Xacro model of a 4-DOF industrial robotic arm.',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'validate_urdf = four_dof_arm_description.validate_urdf:main',
        ],
    },
)
