# four_dof_arm_description

URDF/Xacro model of a 4-DOF articulated industrial robotic arm for **ROS 2 Humble** (Iron-compatible), with RViz2 visualization and a Python URDF validator.

Author: Radharani Pradhan

> **Status:** The files were generated and the validator logic was exercised in a sandbox **without ROS 2**. The `colcon build`, `ros2 launch`, RViz2 and TF commands below have **not yet been run** – run them on your Ubuntu machine and record results in `REPORT.md`.

## 1. Robot structure

| # | Joint | Type | Parent → Child | Axis | Origin (xyz, m) | Limits (rad) |
|---|-------|------|----------------|------|-----------------|--------------|
| 1 | `joint_1` | revolute | base_link → shoulder_link | Z | 0 0 0.06 | −π … π |
| 2 | `joint_2` | revolute | shoulder_link → upper_arm_link | Y | 0 0 0.10 | −1.8 … 1.8 |
| 3 | `joint_3` | revolute | upper_arm_link → forearm_link | Y | 0 0 0.30 | −2.4 … 2.4 |
| 4 | `joint_4` | revolute | forearm_link → wrist_link | X | 0 0 0.25 | −π … π |
| – | `tool_fixed_joint` | fixed | wrist_link → tool_link | – | 0 0 0.08 | – |

| Link | Shape | Size (m) | Mass (kg) | Colour |
|------|-------|----------|-----------|--------|
| base_link | cylinder | r 0.10, h 0.06 | 2.0 | dark grey |
| shoulder_link | cylinder | r 0.06, h 0.10 | 1.0 | blue |
| upper_arm_link | box | 0.06 × 0.06 × 0.30 | 1.5 | orange |
| forearm_link | box | 0.05 × 0.05 × 0.25 | 1.0 | green |
| wrist_link | cylinder | r 0.035, h 0.08 | 0.4 | yellow |
| tool_link | box | 0.04 × 0.02 × 0.06 | 0.2 | red |

Each link frame sits at its lower joint, +Z along the link. At the zero pose the arm points straight up and `tool_link` is at **(0, 0, 0.79)** relative to `base_link` (0.06+0.10+0.30+0.25+0.08).

### TF tree
```
base_link
└── shoulder_link        (joint_1, Z)
    └── upper_arm_link   (joint_2, Y)
        └── forearm_link (joint_3, Y)
            └── wrist_link   (joint_4, X)
                └── tool_link    (tool_fixed_joint, fixed)
```

## 2. Install dependencies (Ubuntu 22.04 + ROS 2 Humble)

```bash
sudo apt update
sudo apt install -y ros-humble-desktop ros-humble-xacro \
  ros-humble-robot-state-publisher ros-humble-joint-state-publisher-gui \
  ros-humble-rviz2 ros-humble-tf2-tools ros-humble-tf2-ros \
  python3-colcon-common-extensions
```
(For Iron replace `humble` with `iron`.)

## 3. Build

```bash
mkdir -p ~/ros2_ws/src
cp -r ROS2_URDF_4DOF_Arm_RadharaniPradhan/four_dof_arm_description ~/ros2_ws/src/
cd ~/ros2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select four_dof_arm_description
source install/setup.bash
```

## 4. Launch

```bash
ros2 launch four_dof_arm_description display.launch.py
```
Starts `robot_state_publisher`, `joint_state_publisher_gui` (sliders for the 4 joints) and RViz2 with `rviz/display.rviz` (Grid, RobotModel, TF; fixed frame `base_link`).
Options: `gui:=false`, `rviz:=false`.

## 5. Validate the URDF

```bash
# Python validator (expands the xacro, runs ~85 checks, exit code 0 = pass)
ros2 run four_dof_arm_description validate_urdf
# or directly on a file
python3 src/four_dof_arm_description/four_dof_arm_description/validate_urdf.py \
  src/four_dof_arm_description/urdf/four_dof_arm.urdf.xacro

# Independent check with ROS tools
xacro src/four_dof_arm_description/urdf/four_dof_arm.urdf.xacro > /tmp/four_dof_arm.urdf
sudo apt install -y liburdfdom-tools
check_urdf /tmp/four_dof_arm.urdf
urdf_to_graphviz /tmp/four_dof_arm.urdf /tmp/four_dof_arm   # creates .gv and .pdf
```

## 6. Verify TF, topics and nodes (launch running in another terminal)

```bash
source ~/ros2_ws/install/setup.bash
ros2 run tf2_tools view_frames                       # writes frames_<time>.pdf (TF tree)
ros2 run tf2_ros tf2_echo base_link tool_link        # zero pose: translation [0, 0, 0.790]
ros2 topic list                                      # expect /joint_states /robot_description /tf /tf_static
ros2 topic echo /joint_states --once
ros2 topic echo /tf --once
ros2 node list                                       # expect /robot_state_publisher /joint_state_publisher_gui /rviz2
ros2 param get /robot_state_publisher robot_description
```
Move the sliders and re-run `tf2_echo`; the translation must change. 

## 7. Troubleshooting

| Problem | Fix |
|---------|-----|
| `Package 'four_dof_arm_description' not found` | `source ~/ros2_ws/install/setup.bash` in every new terminal |
| `xacro: command not found` | `sudo apt install ros-humble-xacro` and source `/opt/ros/humble/setup.bash` |
| RViz shows "No transform from [link] to [base_link]" or empty model | `robot_state_publisher` not running or no `/joint_states`; start with the launch file; check `ros2 node list` |
| RobotModel has an error status | Set Description Topic to `/robot_description`, Durability = Transient Local (already set in the config) |
| Slider window missing | `sudo apt install ros-humble-joint-state-publisher-gui`; needs a desktop session (not plain SSH) |
| `colcon build` setuptools warnings/errors | `pip3 install setuptools==58.2.0` (known Humble issue), then rebuild |
| RViz crashes in a VM | `export LIBGL_ALWAYS_SOFTWARE=1` before launching |
| Edited files not updated | `colcon build --packages-select four_dof_arm_description` again (or build with `--symlink-install`) |

## 8. Package layout
```
four_dof_arm_description/
├── package.xml  setup.py  setup.cfg
├── resource/four_dof_arm_description
├── four_dof_arm_description/{__init__.py, validate_urdf.py}
├── urdf/four_dof_arm.urdf.xacro
├── launch/display.launch.py
├── rviz/display.rviz
├── docs/SCREENSHOT_GUIDE.md
├── README.md  REPORT.md
```
