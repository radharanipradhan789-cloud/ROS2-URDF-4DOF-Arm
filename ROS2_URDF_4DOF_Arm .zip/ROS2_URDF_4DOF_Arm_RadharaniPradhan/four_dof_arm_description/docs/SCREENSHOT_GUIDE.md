# Screenshot guide – capture these yourself

Only submit screenshots you actually captured. Save them in `docs/screenshots/` (create the folder) with these names.

| File | How to capture | What it must show |
|------|----------------|-------------------|
| `01_build_success.png` | Terminal after `colcon build --packages-select four_dof_arm_description` | "Finished <<< four_dof_arm_description" |
| `02_validation.png` | Terminal after `ros2 run four_dof_arm_description validate_urdf` | All PASS and `RESULT: N passed, 0 failed` |
| `03_rviz_zero_pose.png` | RViz2, all sliders at 0 | Coloured robot, grid, TF axes, Fixed Frame = base_link |
| `04_rviz_moved_pose.png` | Move joint_2, joint_3, joint_4 sliders | Arm bent, joint GUI visible alongside |
| `05_rviz_tf_frames.png` | RViz2 with TF display expanded | Six frame names visible |
| `06_tf_tree.png` | `ros2 run tf2_tools view_frames`, open the PDF | base_link → … → tool_link chain |
| `07_tf2_echo.png` | `ros2 run tf2_ros tf2_echo base_link tool_link` | Translation [0, 0, 0.790] at zero pose |
| `08_topics_nodes.png` | `ros2 topic list` and `ros2 node list` | /joint_states, /tf, /robot_description; 3 nodes |
| `09_check_urdf.png` (optional) | `check_urdf /tmp/four_dof_arm.urdf` | Successfully parsed, link tree |

Tip: use `gnome-screenshot -w` or the PrintScreen key; crop out unrelated windows.
